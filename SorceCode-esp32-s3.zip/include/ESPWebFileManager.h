#include <AsyncTCP.h>
#include "../src/ESPAsyncWebServer/ESPAsyncWebServer.h"
class ESPWebFileManager {
public:
	bool begin(fs::FS& fs);
	String sanitizePath(const String& path);
	void setServer(AsyncWebServer* server);
	void listDir(const char* dirname, uint8_t levels);
	bool deleteRecursive(fs::FS& fs, const String& path);
	bool safeMkdir(const String& path);

private:
	fs::FS* current_fs = nullptr;
	String str_data = "";
	AsyncWebServer* _server = nullptr;
};