#include "../include/ESPWebFileManager.h"
#include "../filemanager.h"

String str_data = "";

bool ESPWebFileManager::begin(fs::FS& fs) {
	current_fs = &fs;
	return true; // Or add filesystem health checks
}

String ESPWebFileManager::sanitizePath(const String& path) {
	String sanitized = path;

	// Replace all instances of double slashes
	while (sanitized.indexOf("//") >= 0) {
		sanitized.replace("//", "/");
	}

	// Remove trailing slash
	if (sanitized.endsWith("/")) {
		sanitized.remove(sanitized.length() - 1);
	}

	// Ensure leading slash
	if (!sanitized.startsWith("/")) {
		sanitized = "/" + sanitized;
	}

	return sanitized;
}

bool ESPWebFileManager::safeMkdir(const String& path) {
	if (current_fs->exists(path)) return true;

	String parent = path.substring(0, path.lastIndexOf('/'));
	if (!parent.isEmpty() && !current_fs->exists(parent)) {
		if (!safeMkdir(parent)) {
			return false;
		}
	}

	return current_fs->mkdir(path);
}

bool ESPWebFileManager::deleteRecursive(fs::FS& fs, const String& path) {
    // Protect "config.json" in the root directory
    String normalized = path;
    normalized.toLowerCase();
    if (normalized == "/config.json") {
        return false;
    }

    File file = fs.open(path);
    if (!file) {
        return false;
    }

    bool success = true;

    if (file.isDirectory()) {
        File entry = file.openNextFile();
        while (entry) {
            String entryPath = path + (path.endsWith("/") ? "" : "/") + entry.name();
            String normalizedEntryPath = entryPath;
            normalizedEntryPath.toLowerCase();

            // Protect "config.json" in the root directory for all recursive calls
            if (normalizedEntryPath == "/config.json") {
                entry.close();
                entry = file.openNextFile();
                continue;
            }

            if (entry.isDirectory()) {
                if (!deleteRecursive(fs, entryPath)) {
                    success = false;
                }
            }
            else {
                if (!fs.remove(entryPath)) {
                    success = false;
                }
            }
            entry.close();
            entry = file.openNextFile();
        }
        file.close();
        if (!fs.rmdir(path)) {
            success = false;
        }
    }
    else {
        file.close();
        if (!fs.remove(path)) {
            success = false;
        }
    }

    return success;
}

void ESPWebFileManager::listDir(const char* dirname, uint8_t levels) {
    File root = current_fs->open(dirname);
    if (!root || !root.isDirectory()) {
        return;
    }

    str_data = ""; // Clear the response string
    File file = root.openNextFile();

    while (file) {
        // Skip config.json in root directory
        String fileName = file.name();
        if (fileName.equalsIgnoreCase("/config.json") || 
            (dirname[0] == '/' && dirname[1] == '\0' && fileName.equalsIgnoreCase("config.json"))) {
            file = root.openNextFile();
            continue;
        }

        if (!str_data.isEmpty()) {
            str_data += ":"; // Separate entries with a colon
        }

        if (file.isDirectory()) {
            str_data += "1," + String(file.name()) + ",-"; // Folders don't have sizes
        }
        else {
            str_data += "0," + String(file.name()) + "," + String(file.size());
        }
        file = root.openNextFile();
    }

    file.close();
}

void ESPWebFileManager::setServer(AsyncWebServer* server) {
	if (server == nullptr) {
		return;
	}
	_server = server;

	_server->on("/file", HTTP_GET, [&](AsyncWebServerRequest* request) {
		AsyncWebServerResponse* response = request->beginResponse(200, "text/html", filemanager, filemanager_len);
		response->addHeader("Content-Encoding", "gzip");
		request->send(response);
		// request->send(200, "text/html", html_page); 
		// request->send(200, "text/plain", "Test route working");
		});
		
	_server->on("/fm-get-fs-type", HTTP_GET, [&](AsyncWebServerRequest* request) {
		String fsTypeStr = String(1);
		request->send(200, "text/plain", fsTypeStr);
		});

	_server->on("/fm-get-folder-contents", HTTP_GET, [&](AsyncWebServerRequest* request) {
		listDir(request->arg("path").c_str(), 0);
		request->send(200, "text/plain", str_data);
		});

	// Modified upload handler to support folder uploads with directory structure
	_server->on("/fm-upload", HTTP_POST,
		[&](AsyncWebServerRequest* request) {
			request->send(200, "application/json", "{\"status\":\"success\",\"message\":\"File upload complete\"}");
		},
		[&](AsyncWebServerRequest* request, String filename, size_t index, uint8_t* data, size_t len, bool final) {
			// Get base path from query parameter
			String basePath = "/";
			if (request->hasParam("path")) {
				basePath = request->getParam("path")->value();
			}

			// Sanitize base path
			basePath = sanitizePath(basePath);
			if (!basePath.endsWith("/")) basePath += "/";

			// Process the filename which may contain relative path
			String relativePath = filename;

			// Remove any leading slashes or ./ from the relative path
			while (relativePath.startsWith("/") || relativePath.startsWith("./")) {
				if (relativePath.startsWith("/")) {
					relativePath = relativePath.substring(1);
				}
				else if (relativePath.startsWith("./")) {
					relativePath = relativePath.substring(2);
				}
			}

			// Construct full current_fstem path
			String fullPath = basePath + relativePath;

			// Create parent directories if they don't exist
			int lastSlash = fullPath.lastIndexOf('/');
			if (lastSlash > 0) {
				String parentDir = fullPath.substring(0, lastSlash);
				if (!current_fs->exists(parentDir)) {
					safeMkdir(parentDir);
				}
			}

			// Handle the file data
			if (!index) {
				// First chunk - create or truncate the file
				if (current_fs->exists(fullPath)) {
					current_fs->remove(fullPath);
				}
			}

			// Open file and write data
			File file = current_fs->open(fullPath, FILE_APPEND);
			if (!file) {
				Serial.printf("Failed to open file for writing: %s\n", fullPath.c_str());
				return;
			}

			if (file.write(data, len) != len) {
				Serial.printf("Write failed for file: %s\n", fullPath.c_str());
			}
			file.close();

			if (final) {
				Serial.printf("Upload complete: %s\n", fullPath.c_str());
			}
		}
	);

	// Route to create a new folder
	_server->on("/fm-create-folder", HTTP_GET, [&](AsyncWebServerRequest* request) {
		String path = request->hasParam("path") ? request->getParam("path")->value() : "";
		path = sanitizePath(path);

		if (path.isEmpty()) {
			request->send(400, "application/json", "{\"status\":\"error\",\"message\":\"Folder path not provided\"}");
			return;
		}

		// Refresh directory cache
		String parent = path.substring(0, path.lastIndexOf('/'));
		if (!parent.isEmpty()) {
			File dir = current_fs->open(parent);
			if (dir) dir.rewindDirectory();
			dir.close();
		}

		// Use safe folder creation
		if (safeMkdir(path)) {
			request->send(200, "application/json", "{\"status\":\"success\",\"message\":\"Folder created successfully\"}");
		}
		else {
			request->send(500, "application/json", "{\"status\":\"error\",\"message\":\"Failed to create folder\"}");
		}
		});

	_server->on("/fm-delete-folder", HTTP_GET, [&](AsyncWebServerRequest* request) {
		String path = request->hasParam("path") ? request->getParam("path")->value() : "";
		path = sanitizePath(path); // Sanitize the folder path

		if (path.isEmpty()) {
			request->send(400, "application/json", "{\"status\":\"error\",\"message\":\"Folder path not provided\"}");
			return;
		}

		if (current_fs->exists(path)) {
			if (ESPWebFileManager::deleteRecursive(*current_fs, path)) {
				request->send(200, "application/json", "{\"status\":\"success\",\"message\":\"Folder deleted successfully\"}");
			}
			else {
				request->send(500, "application/json", "{\"status\":\"error\",\"message\":\"Failed to delete folder contents\"}");
			}
		}
		else {
			request->send(404, "application/json", "{\"status\":\"error\",\"message\":\"Folder not found\"}");
		}
		});


	_server->on("/fm-delete", HTTP_GET, [&](AsyncWebServerRequest* request) {
		String path = request->hasParam("path") ? request->getParam("path")->value() : "";
		path = sanitizePath(path); // Apply sanitization

		if (current_fs->exists(path)) {
			current_fs->remove(path);
			request->send(200, "application/json", "{\"status\":\"success\",\"message\":\"File deleted successfully\"}");
		}
		else {
			request->send(404, "application/json", "{\"status\":\"error\",\"message\":\"File not found\"}");
		}
		});

	_server->on("/fm-download", HTTP_GET, [&](AsyncWebServerRequest* request) {
		String path;
		if (request->hasParam("path")) {
			path = request->getParam("path")->value();
		}
		else {
			request->send(400, "application/json", "{\"status\":\"error\",\"message\":\"Path not provided\"}");
			return;
		}
		path = sanitizePath(path); // Apply sanitization
		if (current_fs->exists(path)) {
			request->send(*current_fs, path, String(), true);
		}
		else {
			request->send(404, "application/json", "{\"status\":\"error\",\"message\":\"File not found\"}");
		}
		});
}