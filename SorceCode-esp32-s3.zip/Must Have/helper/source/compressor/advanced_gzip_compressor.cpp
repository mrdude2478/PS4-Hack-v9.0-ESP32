#include <iostream>
#include <fstream>
#include <vector>
#include <zlib.h>
#include <cstring>

bool compressToGzipAdvanced(const std::string& inputFile, const std::string& outputFile) {
    // Open input file
    std::ifstream in(inputFile, std::ios::binary);
    if (!in.is_open()) {
        std::cerr << "Error: Could not open input file " << inputFile << std::endl;
        return false;
    }

    // Open output file with maximum compression level (9)
    gzFile out = gzopen(outputFile.c_str(), "wb9");
    if (!out) {
        std::cerr << "Error: Could not open output file " << outputFile << std::endl;
        in.close();
        return false;
    }

    // Set advanced compression parameters
    const int windowBits = 15 + 16; // 15 (MAX_WBITS) + 16 for gzip header
    const int memLevel = 9;         // Maximum memory usage (1-9)
    
    if (gzsetparams(out, Z_BEST_COMPRESSION, Z_DEFAULT_STRATEGY) != Z_OK) {
        std::cerr << "Error: Failed to set compression parameters" << std::endl;
        gzclose(out);
        in.close();
        return false;
    }

    // Set larger buffer size (128KB)
    gzbuffer(out, 128 * 1024);

    // Buffer for reading (1MB chunks)
    const size_t BUFFER_SIZE = 1024 * 1024;
    std::vector<char> buffer(BUFFER_SIZE);

    // Compress data
    while (!in.eof()) {
        in.read(buffer.data(), BUFFER_SIZE);
        std::streamsize bytesRead = in.gcount();

        if (bytesRead > 0) {
            if (gzwrite(out, buffer.data(), static_cast<unsigned>(bytesRead)) == 0) {
                std::cerr << "Error: Failed to write compressed data" << std::endl;
                gzclose(out);
                in.close();
                return false;
            }
        }
    }

    // Clean up
    if (gzclose(out) != Z_OK) {
        std::cerr << "Error: Failed to close compressed file" << std::endl;
        in.close();
        return false;
    }
    in.close();

    return true;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cout << "Advanced GZIP Compressor\n";
        std::cout << "Usage: " << argv[0] << " <input_file> <output_file.gz>\n";
        std::cout << "Note: Output file will automatically get .gz extension if not provided\n";
        return 1;
    }

    std::string inputFile = argv[1];
    std::string outputFile = argv[2];

    // Ensure output file ends with .gz
    if (outputFile.size() < 3 || outputFile.substr(outputFile.size() - 3) != ".gz") {
        outputFile += ".gz";
    }

    std::cout << "Compressing " << inputFile << " to " << outputFile << " with optimized settings...\n";

    if (compressToGzipAdvanced(inputFile, outputFile)) {
        std::cout << "Compression successful!\n";
        return 0;
    } else {
        std::cerr << "Compression failed!\n";
        return 1;
    }
}