#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

void generateHeader(const std::string& inputFile, const std::string& outputFile, const std::string& arrayName) {
    std::ifstream in(inputFile, std::ios::binary);
    if (!in) {
        std::cerr << "Error opening input file: " << inputFile << "\n";
        return;
    }

    std::ofstream out(outputFile);
    if (!out) {
        std::cerr << "Error opening output file: " << outputFile << "\n";
        return;
    }

    // Header
    out << "#pragma once\n";
    out << "#include <stdint.h>\n\n";
    out << "const uint8_t " << arrayName << "[] PROGMEM = {\n    ";

    size_t count = 0;
    char byte;
    while (in.get(byte)) {
        out << "0x" << std::hex << std::setw(2) << std::setfill('0') << (static_cast<unsigned>(byte) & 0xFF);
        if (!in.eof()) out << ", ";

        if (++count % 16 == 0) out << "\n    ";
    }

    out << "\n};\n";
    out << "const unsigned int " << arrayName << "_len = sizeof(" << arrayName << ");\n";

    std::cout << "Header file generated: " << outputFile << "\n";
}

int main(int argc, char* argv[]) {
    if (argc != 4) {
        std::cerr << "Usage: bin2header <input file> <output .h file> <array name>\n";
        return 1;
    }

    generateHeader(argv[1], argv[2], argv[3]);
    return 0;
}
