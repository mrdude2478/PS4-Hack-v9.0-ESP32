#include <iostream>
#include <fstream>
#include <string>
#include <regex>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cerr << "Usage: header2bin <input .h> <output file>\n";
        return 1;
    }

    std::ifstream in(argv[1]);
    if (!in) {
        std::cerr << "Failed to open input header file.\n";
        return 1;
    }

    std::ofstream out(argv[2], std::ios::binary);
    if (!out) {
        std::cerr << "Failed to open output binary file.\n";
        return 1;
    }

    std::string line;
    std::regex hexByteRegex(R"(0x[0-9a-fA-F]{2})");
    std::smatch match;

    while (std::getline(in, line)) {
        auto begin = std::sregex_iterator(line.begin(), line.end(), hexByteRegex);
        auto end = std::sregex_iterator();

        for (std::sregex_iterator i = begin; i != end; ++i) {
            std::string byteStr = (*i).str();
            unsigned int byte;
            std::stringstream ss;
            ss << std::hex << byteStr;
            ss >> byte;
            out.put(static_cast<char>(byte));
        }
    }

    std::cout << "Successfully created binary file: " << argv[2] << "\n";
    return 0;
}
