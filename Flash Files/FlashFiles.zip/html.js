/*
/ means the root of the current drive;
./ means the current directory;
../ means the parent of the current directory.
*/

var payloadFile = sessionStorage.getItem('payload');
var payloadTitle = sessionStorage.getItem('title');
//var message = 'Exploiting console and injecting ';

if (payloadFile === null || payloadFile === "") {
    payloadFile = './payloads/hen/goldhen.bin';
}

if (payloadTitle === null || payloadTitle === "") {
    payloadTitle = 'GoldHEN';
}

const tooltipText = payloadTitle;
document.getElementById("tooltip").textContent = tooltipText;


function showMessage(msg) {
    const statusText = document.getElementById("statusText");
    if (statusText) {
        statusText.innerHTML = "<h1>" + msg + "</h1>";
    }
    document.getElementById("message").style.display = 'block';
}

function cachepage() {
    if (window.applicationCache.status == '0') {
        window.location.replace("./cache.html");
    }
    else {
        showMessage("Cache is already installed");
    }
}

function LapseHax() {
    showMessage("Lapse, Attempting to inject: " + payloadTitle);
    import('./LapseHack/alert.mjs');
}

function ExFatHax() {
    showMessage("ExFatHax, Attempting to inject: " + payloadTitle);

    // Dynamically add loader.js (non-module script)
    const loaderScript = document.createElement('script');
    loaderScript.src = '/ExFatHack/loader.js';
    loaderScript.defer = true;
    document.head.appendChild(loaderScript);

    // Dynamically add exploitunpacked.js (module script)
    const moduleScript = document.createElement('script');
    moduleScript.src = '/ExFatHack/exploitunpacked.js';
    moduleScript.type = 'module';
    document.head.appendChild(moduleScript);
}

function callalert() {
    const uselapse = localStorage.getItem('checkboxState3') === 'true';
    if (uselapse) {
        LapseHax();
    }
    else {
        ExFatHax();
    }
}

function goldhen() {
    payloadTitle = sessionStorage.getItem('title');
    payloadFile = sessionStorage.getItem('payload');
    callalert();
}

function vtx() {
    payloadFile = './payloads/hen/ps4-hen-900-vtx.bin';
    payloadTitle = 'PS4HEN v2.1.5';
    callalert();
}

function historyblocker() {
    payloadFile = './payloads/blockers/historyblocker.bin';
    payloadTitle = 'History Blocker';
    callalert();
}

function disabledupdates() {
    payloadFile = './payloads/blockers/disableupdates.bin';
    payloadTitle = 'Disable Updates';
    callalert();
}

function enableupdates() {
    payloadFile = './payloads/blockers/enableupdates.bin';
    payloadTitle = 'Enable Updates';
    callalert();
}

function bloader() {
    const uselapse = localStorage.getItem('checkboxState3') === 'true';
    if (uselapse) {
    	payloadTitle = 'Binloader';
    	callalert();
    }
    else {
    	alert('Binloader only works when using the Lapse Exploit!');
    }
}

function dumpG() {
    payloadFile = './payloads/dumpers/dumperG.bin';
    payloadTitle = 'Game Dumper';
    callalert();
}

function dumpU() {
    payloadFile = './payloads/dumpers/dumperU.bin';
    payloadTitle = 'Game Update Dumper';
    callalert();
}

function dumpGU() {
    payloadFile = './payloads/dumpers/dumperGU.bin';
    payloadTitle = 'Game and Update Dumper';
    callalert();
}

function dumpM() {
    payloadFile = './payloads/dumpers/dumperM.bin';
    payloadTitle = 'Dump and Merge Game + Update';
    callalert();
}

function dbbackup() {
    payloadFile = './payloads/database/backup.bin';
    payloadTitle = 'Database backup';
    callalert();
}

function dbrestore() {
    payloadFile = './payloads/database/restore.bin';
    payloadTitle = 'Database restore';
    callalert();
}

function reset() {
    const checkbox = document.getElementById('myCheckbox');
    if (checkbox) {
        checkbox.checked = false;
        localStorage.setItem('checkboxState', 'false');
    }
}

//checkbox sections
document.addEventListener('DOMContentLoaded', () => {
    const checkbox = document.getElementById('myCheckbox');
    const checkbox2 = document.getElementById('myCheckbox2');
    const checkbox3 = document.getElementById('myCheckbox3');

    // Load saved checkbox state from localStorage
    const savedState = localStorage.getItem('checkboxState');
    const savedState2 = localStorage.getItem('checkboxState2');
    const savedState3 = localStorage.getItem('checkboxState3');

    if (savedState !== null && checkbox) {
        checkbox.checked = savedState === 'true';
        if (checkbox.checked) onCheckboxChange(true);
    }

    if (savedState2 !== null && checkbox2) {
        checkbox2.checked = savedState2 === 'true';
        if (checkbox2.checked) onCheckboxChange2(true);
    }

    if (savedState3 !== null && checkbox3) {
        checkbox3.checked = savedState3 === 'true';
        if (checkbox3.checked) onCheckboxChange3(true);
    }

    // Save checkbox state and optionally trigger action
    if (checkbox) {
        checkbox.addEventListener('change', function () {
            localStorage.setItem('checkboxState', checkbox.checked);
            onCheckboxChange(checkbox.checked);
        });
    }

    if (checkbox2) {
        checkbox2.addEventListener('change', function () {
            localStorage.setItem('checkboxState2', checkbox2.checked);
            onCheckboxChange2(checkbox2.checked);
        });
    }

    if (checkbox3) {
        checkbox3.addEventListener('change', function () {
            localStorage.setItem('checkboxState3', checkbox3.checked);
            onCheckboxChange3(checkbox3.checked);
        });
    }

    function onCheckboxChange(isChecked) {
        if (isChecked) {
            goldhen();
        }
    }

    function onCheckboxChange2(isChecked) {
        if (isChecked) {
            vtx();
        }
    }

    function onCheckboxChange3(isChecked) {
        if (isChecked) {
            //
        }
    }
});

function showPopup() {
    document.getElementById('popup').classList.add('show');
}

function hidePopup() {
    document.getElementById('popup').classList.remove('show');
}