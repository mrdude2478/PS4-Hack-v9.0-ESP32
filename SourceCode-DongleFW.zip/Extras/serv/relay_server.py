from flask import Flask, request, Response
import requests

app = Flask(__name__)

@app.route('/check')
def check_file():
    github_url = request.args.get('url')
    if not github_url:
        return "Missing 'url' parameter", 400

    try:
        resp = requests.head(github_url, allow_redirects=True, timeout=10)
        return Response(f"GitHub status: {resp.status_code}", status=resp.status_code)
    except Exception as e:
        return f"Error contacting GitHub: {str(e)}", 500

@app.route('/fetch')
def fetch_file():
    github_url = request.args.get('url')
    if not github_url:
        return "Missing 'url' parameter", 400

    try:
        resp = requests.get(github_url, stream=True, timeout=10)
        return Response(resp.content, status=resp.status_code, content_type=resp.headers.get('Content-Type', 'application/octet-stream'))
    except Exception as e:
        return f"Error fetching file: {str(e)}", 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
