<?php
$url = $_GET['url'] ?? '';

if (!$url || stripos($url, 'https://raw.githubusercontent.com') !== 0) {
    http_response_code(400);
    echo "Invalid or missing URL.";
    exit;
}

// Set timeout for HTTP requests
$context = stream_context_create(['http' => ['timeout' => 10]]);

// Fetch headers from the URL
$headers = get_headers($url, true, $context);
$status = $headers[0];

if (strpos($status, "200") === false) {
    http_response_code(404);
    echo "File not found or inaccessible.";
    exit;
}

// Handle HEAD requests
if ($_SERVER['REQUEST_METHOD'] === 'HEAD') {
    header("Content-Type: application/octet-stream");
    if (isset($headers['Content-Length'])) {
        header("Content-Length: " . $headers['Content-Length']);
    }
    exit;
}

// Fetch content to buffer it
$content = file_get_contents($url, false, $context);
if ($content === false) {
    http_response_code(500);
    echo "Failed to fetch file.";
    exit;
}

// Set headers for GET requests
header("Content-Type: application/octet-stream");
header("Content-Length: " . strlen($content));

// Output the content
echo $content;
?>