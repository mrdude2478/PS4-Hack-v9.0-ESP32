#include <fstream>
#include <iostream>
#include <string>
#include <getopt.h>
#include <vector>
#include <sstream>

// Structure to hold search and replace pairs
struct Replacement {
    std::string search;
    std::string replace;
};

// Load replacements from a file
std::vector<Replacement> loadReplacements(const std::string& replacementsFile, bool verbose) {
    std::vector<Replacement> replacements;
    std::ifstream file(replacementsFile);
    if (!file.is_open()) {
        std::cerr << "Error: Cannot open replacements file " << replacementsFile << "\n";
        return replacements;
    }

    std::string line;
    int lineNumber = 0;
    while (std::getline(file, line)) {
        lineNumber++;
        // Skip empty lines or lines starting with #
        if (line.empty() || line[0] == '#') continue;

        // Find the delimiter
        size_t delimPos = line.find(':');
        if (delimPos == std::string::npos) {
            if (verbose) {
                std::cerr << "Warning: Skipping malformed line " << lineNumber << " in replacements file: '" << line << "' (missing ':')\n";
            }
            continue;
        }

        std::string search = line.substr(0, delimPos);
        std::string replace = line.substr(delimPos + 1);
        
        // Trim whitespace
        auto trim = [](std::string& s) {
            s.erase(0, s.find_first_not_of(" \t\r\n"));
            s.erase(s.find_last_not_of(" \t\r\n") + 1);
        };
        trim(search);
        trim(replace);

        if (search.empty()) {
            if (verbose) {
                std::cerr << "Warning: Skipping line " << lineNumber << " with empty search string\n";
            }
            continue;
        }

        replacements.push_back({search, replace});
        if (verbose) {
            std::cerr << "Loaded replacement: search='" << search << "', replace='" << replace << "'\n";
        }
    }

    file.close();
    return replacements;
}

// Apply all replacements to the content
void applyReplacements(std::string& content, const std::vector<Replacement>& replacements, bool verbose) {
    for (const auto& r : replacements) {
        size_t pos = 0;
        size_t count = 0;
        while ((pos = content.find(r.search, pos)) != std::string::npos) {
            content.replace(pos, r.search.length(), r.replace);
            pos += r.replace.length();
            count++;
            if (verbose) {
                std::cerr << "Replaced '" << r.search << "' with '" << r.replace << "' at position " << pos << "\n";
            }
        }
        if (verbose) {
            std::cerr << "Total replacements for '" << r.search << "': " << count << "\n";
        }
    }
}

void printUsage(const char* progName) {
    std::cerr << "Usage: " << progName << " -i <input_html_file> -o <output_html_file> -r <replacements_file> [--verbose]\n"
              << "  -i <file>            : Input HTML file to process\n"
              << "  -o <file>            : Output corrected HTML file\n"
              << "  -r <file>            : File containing search:replace pairs (one per line)\n"
              << "  --verbose            : Log replacement details\n"
              << "  --help              : Show this help message\n";
}

int main(int argc, char* argv[]) {
    std::string inputFile, outputFile, replacementsFile;
    bool verbose = false;

    struct option longOptions[] = {
        {"verbose", no_argument, 0, 'v'},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    int opt;
    while ((opt = getopt_long(argc, argv, "i:o:r:", longOptions, nullptr)) != -1) {
        switch (opt) {
            case 'i':
                inputFile = optarg;
                break;
            case 'o':
                outputFile = optarg;
                break;
            case 'r':
                replacementsFile = optarg;
                break;
            case 'v':
                verbose = true;
                break;
            case 'h':
                printUsage(argv[0]);
                return 0;
            default:
                printUsage(argv[0]);
                return 1;
        }
    }

    if (inputFile.empty() || outputFile.empty() || replacementsFile.empty()) {
        printUsage(argv[0]);
        return 1;
    }

    // Load replacements
    std::vector<Replacement> replacements = loadReplacements(replacementsFile, verbose);
    if (replacements.empty() && verbose) {
        std::cerr << "Warning: No valid replacements loaded from " << replacementsFile << "\n";
    }

    // Read input file
    std::ifstream inFile(inputFile);
    if (!inFile.is_open()) {
        std::cerr << "Error: Cannot open input file " << inputFile << "\n";
        return 1;
    }

    std::string content((std::istreambuf_iterator<char>(inFile)), std::istreambuf_iterator<char>());
    inFile.close();

    // Apply replacements
    applyReplacements(content, replacements, verbose);

    // Write output file
    std::ofstream outFile(outputFile);
    if (!outFile.is_open()) {
        std::cerr << "Error: Cannot open output file " << outputFile << "\n";
        return 1;
    }

    outFile << content;
    outFile.close();

    if (verbose) {
        std::cerr << "Corrected HTML written to " << outputFile << "\n";
    }
    std::cout << "Processed HTML written to " << outputFile << "\n";

    return 0;
}