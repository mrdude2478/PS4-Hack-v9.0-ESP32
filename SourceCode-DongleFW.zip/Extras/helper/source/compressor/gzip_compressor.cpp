#include <iostream>
#include <fstream>
#include <vector>
#include <zlib.h>
#include <cstring>

bool compressToGzip(const std::string& inputFile, const std::string& outputFile, int compressionLevel = Z_BEST_COMPRESSION) {
    // Open input file
    std::ifstream in(inputFile, std::ios::binary);
    if (!in.is_open()) {
        std::cerr << "Error: Could not open input file " << inputFile << std::endl;
        return false;
    }

    // Open output file
    gzFile out = gzopen(outputFile.c_str(), ("wb" + std::to_string(compressionLevel)).c_str());
    if (!out) {
        std::cerr << "Error: Could not open output file " << outputFile << std::endl;
        in.close();
        return false;
    }

    // Buffer for reading
    const size_t BUFFER_SIZE = 1024 * 1024; // 1MB buffer
    std::vector<char> buffer(BUFFER_SIZE);

    // Compress data
    while (!in.eof()) {
        in.read(buffer.data(), BUFFER_SIZE);
        std::streamsize bytesRead = in.gcount();

        if (bytesRead > 0) {
            if (gzwrite(out, buffer.data(), static_cast<unsigned>(bytesRead)) == 0) {
                std::cerr << "Error: Failed to write compressed data" << std::endl;
                gzclose(out);
                in.close();
                return false;
            }
        }
    }

    // Clean up
    gzclose(out);
    in.close();

    return true;
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cout << "Usage: " << argv[0] << " <input_file> <output_file.gz>" << std::endl;
        return 1;
    }

    std::string inputFile = argv[1];
    std::string outputFile = argv[2];

    // Ensure output file ends with .gz
    if (outputFile.size() < 3 || outputFile.substr(outputFile.size() - 3) != ".gz") {
        outputFile += ".gz";
    }

    std::cout << "Compressing " << inputFile << " to " << outputFile << "..." << std::endl;

    if (compressToGzip(inputFile, outputFile)) {
        std::cout << "Compression successful!" << std::endl;
        return 0;
    } else {
        std::cerr << "Compression failed!" << std::endl;
        return 1;
    }
}