#include <Arduino.h>
#include "../include/ButtonHandler.h"

// Configurable pin
static int buttonPin;

// Thresholds
const unsigned long LONG_PRESS_TIME = 3000;
const unsigned long DOUBLE_PRESS_GAP = 200;

// State tracking
static bool lastButtonState = HIGH;
static bool buttonPressed = false;
static bool longPressTriggered = false;
static unsigned long buttonDownTime = 0;
static unsigned long lastButtonUpTime = 0;
static int pressCount = 0;

// Exposed so user can override
__attribute__((weak)) void onSinglePress() {
  //Serial.println("Single Press");
}

__attribute__((weak)) void onDoublePress() {
  //Serial.println("Double Press");
}

__attribute__((weak)) void onLongPress() {
  //Serial.println("Long Press (≥3s)");
}

void buttonTask(void *pvParams) {
  pinMode(buttonPin, INPUT_PULLUP);
  for (;;) {
    bool currentState = digitalRead(buttonPin);
    unsigned long now = millis();

    if (lastButtonState == HIGH && currentState == LOW) {
      buttonDownTime = now;
      buttonPressed = true;
      longPressTriggered = false;
    }

    if (buttonPressed && !longPressTriggered && currentState == LOW && (now - buttonDownTime >= LONG_PRESS_TIME)) {
      onLongPress();
      longPressTriggered = true;
      pressCount = 0;
    }

    if (lastButtonState == LOW && currentState == HIGH) {
      if (!longPressTriggered) {
        pressCount++;
        lastButtonUpTime = now;
      }
      buttonPressed = false;
    }

    if (!buttonPressed && !longPressTriggered && pressCount > 0 && (now - lastButtonUpTime > DOUBLE_PRESS_GAP)) {
      if (pressCount == 1) onSinglePress();
      else if (pressCount == 2) onDoublePress();
      pressCount = 0;
    }

    lastButtonState = currentState;
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void setupButtonHandler(int pin) {
  buttonPin = pin;
  xTaskCreatePinnedToCore(
    buttonTask,
    "ButtonTask",
    1024, //only set small to save memory as we are only setting a boolean.
    NULL,
    1,
    NULL,
    0
  );
}


/*
In FreeRTOS on ESP32, every function runs on the stack of the current task or interrupt context. There’s no way to magically “run outside the stack” of the calling task.
What you can do is:
From your button handler task, signal another task or the main loop to run that function — e.g., via a queue, semaphore, or a volatile flag.
That way, the heavy function runs in a task with a suitably large stack, not inside the button task.
*/

//example code to run a heavy function...

/*
volatile bool runHeavyFunction = false;

void buttonTask(void* param) {
  for (;;) {
    if (buttonPressed) {
      runHeavyFunction = true;  // just flag it
    }
    vTaskDelay(50 / portTICK_PERIOD_MS);
  }
}

void loop() {
  if (runHeavyFunction) {
    runHeavyFunction = false;
    heavyFunction();  // runs with main task's stack
  }
}
*/