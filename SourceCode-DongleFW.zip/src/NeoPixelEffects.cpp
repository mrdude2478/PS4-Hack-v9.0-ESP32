#include "../include/NeoPixelEffects.h"

static unsigned long lastUpdate = 0;
static bool stateRed = true;
static bool cleanedUp = false; // Move cleanedUp here

void colorCyclePulse(Adafruit_NeoPixel* strip, uint8_t delay) {
    static uint8_t hue = 0;
    static uint8_t pulse = 0;
    unsigned long currentTime = millis();

    if (currentTime - lastUpdate >= delay) {
        // Calculate pulsing brightness (0-MAX_BRIGHTNESS)
        uint8_t brightness = (sin(pulse * PI / 128.0) + 1) * (100 / 2.0);
        pulse++;

        // Convert HSV to RGB
        uint32_t rgb = strip->ColorHSV(hue * 256, 255, brightness);

        // Set all LEDs to the same color
        for (uint16_t i = 0; i < strip->numPixels(); i++) {
            strip->setPixelColor(i, rgb);
        }
        strip->show();

        // Increment hue (slower than pulse)
        if (pulse % 3 == 0) hue++;
        lastUpdate = currentTime;
    }
}

void colorCycle(Adafruit_NeoPixel* strip, uint8_t delay) {
    static uint8_t hue = 0;
    unsigned long currentTime = millis();

    if (currentTime - lastUpdate >= delay) {
        // Convert HSV to RGB with fixed brightness
        uint32_t rgb = strip->ColorHSV(hue * 256, 255, 100 / 2);

        // Set all LEDs to the same color
        for (uint16_t i = 0; i < strip->numPixels(); i++) {
            strip->setPixelColor(i, rgb);
        }
        strip->show();

        // Increment and wrap hue
        hue++;
        lastUpdate = currentTime;
    }
}

void setColor(Adafruit_NeoPixel* strip, uint16_t index, uint8_t r, uint8_t g, uint8_t b) {
    if (index < strip->numPixels()) {
        strip->setPixelColor(index, r, g, b);
        strip->show();
    }
}

void redblue(Adafruit_NeoPixel* strip, uint16_t delay) {
  unsigned long currentMillis = millis();
  if (currentMillis - lastUpdate >= delay) {
    lastUpdate = currentMillis;
    if (stateRed) {
      strip->fill(strip->Color(255, 0, 0)); // red
    } else {
      strip->fill(strip->Color(0, 0, 255)); // blue
    }
    strip->show();
    stateRed = !stateRed;
  }
}

void cleanup(Adafruit_NeoPixel** strip, unsigned long timeout) {
    if (*strip != nullptr && !cleanedUp && millis() > timeout) {
        setColor(*strip, (*strip)->numPixels() - 1, 0, 0, 0); // Set LED black
        (*strip)->clear(); // Clear all LEDs
        (*strip)->show();  // Update the strip

        // Manually call destructor since we used placement new
        (*strip)->~Adafruit_NeoPixel();

        // Free PSRAM
        free(*strip);
        *strip = nullptr;
        cleanedUp = true;
    }
}