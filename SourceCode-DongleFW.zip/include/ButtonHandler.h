#ifndef BUTTON_HANDLER_H
#define BUTTON_HANDLER_H

void setupButtonHandler(int pin);
void onSinglePress();
void onDoublePress();
void onLongPress();

#endif