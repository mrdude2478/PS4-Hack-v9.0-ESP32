#ifndef NEOPIXEL_EFFECTS_H
#define NEOPIXEL_EFFECTS_H

#include <Adafruit_NeoPixel.h>

void colorCyclePulse(Adafruit_NeoPixel* strip, uint8_t delay);
void colorCycle(Adafruit_NeoPixel* strip, uint8_t delay);
void setColor(Adafruit_NeoPixel* strip, uint16_t index, uint8_t r, uint8_t g, uint8_t b);
void redblue(Adafruit_NeoPixel* strip, uint16_t delay);
void cleanup(Adafruit_NeoPixel** strip, unsigned long timeout); // Add timeout parameter

#endif